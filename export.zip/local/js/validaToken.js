//Import Required Packages

var JOSE=require('jose');
var JWT=require('jwt');
var hm = require('header-metadata');



//se lee input como JSON 
session.input.readAsBuffer(function(error, buffer) {
	if (error) {
		
		var ctx = session.name('cache') || session.createContext('cache');
		ctx.setVar('retorno', '1');
		ctx.setVar('error', '1');
		ctx.setVar('EstadoServicio', '100');
		ctx.setVar('EstadoServicioDesc', 'No es posible leer JSON:' + error);
		ctx.setVar('is_data', '1');
        session.reject('No es posible leer entrada: ' + error);

    } else {
	
		if (hm.current.get('access-token') == null){
			var ctx = session.name('cache') || session.createContext('cache');
			ctx.setVar('retorno', '401');
			ctx.setVar('error', '401');
			ctx.setVar('messageError', 'Bad Authenticate');
			ctx.setVar ('reason', 'No se informa el token');
			ctx.setVar('is_data', '1');
			session.reject('El Token no es informado');
		} else {
		
	
		
		//obtener token del mensaje buffer de entrada
		var JWT_TOKEN = hm.current.get('access-token');//json.KEY;
		
		var keyForSign = session.parameters.VALISIGNKEY; //service.login.jwt.sign.cert
        var keyForEncrypt = session.parameters.ENCENCRYPTIONKEY;//services.login.jwt.enc.key
		var decoder = new JWT.Decoder(JWT_TOKEN);
                
		// decodificar con shared secret key CryptoKey.Test 	
		// validar token con audiencia datapower.
		//decodificar token
		decoder.addOperation('decrypt', keyForEncrypt)
                       .addOperation('verify',keyForSign)
		       .addOperation('validate',{'aud':'datapower'})
		       .decode(function(error,claims)
			{

				if(error)
				{
					var ctx = session.name('cache') || session.createContext('cache');
					ctx.setVar('retorno', '401');
			                ctx.setVar('error', '401');
			                ctx.setVar('messageError', 'Bad Authenticate');
			                ctx.setVar ('reason', 'Error decode token JWT : '  + error);
					ctx.setVar('EstadoServicioDesc', 'Error decode token JWT: ' + error);
					ctx.setVar('is_data', '1');
	                // armar error para tipo multiprotocol
					// rejectar
					session.reject('Error al validar token JWT : ' + error);
					
				}
				else
				{       	    
						var expiration = session.parameters.EXPIRATIONJWTMINUTES;	
						// Se actualiza el token, generando uno nuevo, en base a los parametros
						var claimsout={
						"iss":claims.iss,
						"aud":claims.aud, // .
						"rut":claims.rut, // rut cliente
						"app":claims.app,   //
						"canal":claims.canal,
						"iat": new Date().getTime(),
						"exp": (new Date()/1000) + 60*expiration, //Token will get expire in 1 min.
						};

						var rut = claims.rut;
						
						
				}

			}
		);
	
		}
	}
});