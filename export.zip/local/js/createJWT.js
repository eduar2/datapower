// Import Required packages

var JOSE=require('jose');

var JWT=require('jwt');
var hm = require('header-metadata');


//se lee input como JSON
session.INPUT.readAsJSON(function(error,json)
	{

		if(error)
		{

			var ctx = session.name('cache') || session.createContext('cache');
			ctx.setVar('retorno', '1');
			ctx.setVar('error', '1');
			ctx.setVar('EstadoServicio', '100');
			ctx.setVar('EstadoServicioDesc', 'No es posible leer JSON:' + error);
			ctx.setVar('is_data', '1');
			session.reject('unable to read from input: ' + error);
		}
		else
		{
			var claims={
			"iss":"ibm_datapower",
			"aud":"datapower", // .
			"rut":json.RUT, // rut cliente
			"iat": new Date().getTime(),
			"exp": (new Date()/1000) + 60* session.parameters.EXPIRATIONJWTMINUTES, //Token will get expire in x min.
			};
			
			var keyForSign = session.parameters.SIGNKEY;
            var keyForEncrypt =  session.parameters.ENCRYPTIONKEY;
			
			//Sign the token with HRS256 algorithm. Replace ‘Crypto Key Object Name’ with actual object name created on box.
            // CryptoKey.Test  : shared secret key, se debe cambiar
			var jwsHeader=JOSE.createJWSHeader(keyForSign,'HS256');
			
			// use A128CBC-HS256 algorithm and key '32bytes' to encrypt
			//validando 
			var jweHeader = JOSE.createJWEHeader('A128CBC-HS256')
								.setProtected('alg', 'RSA-OAEP-256')
								.setKey(keyForEncrypt );
			//session.parameters.key
			var encoder=new JWT.Encoder(claims);

			encoder.addOperation('sign',jwsHeader)
				   .addOperation('encrypt', jweHeader.setProtected('cty', 'JWT')) 
			// codificar token
			.encode(function(error,token)
				{

					if (error) {
						var ctx = session.name('cache') || session.createContext('cache');
						ctx.setVar('retorno', '1');
						ctx.setVar('error', '1');
						ctx.setVar('EstadoServicio', '16');
						ctx.setVar('EstadoServicioDesc', 'Error encode token JWT' + error);
						ctx.setVar('is_data', '1');
						
						// rejectar
						session.reject('Error encode token JWT:' + error);
					}

					else {
						var salida;
						salida = {'firstName': 'Jack', 'lastName':'Steve','tmpPassword':false,'userRoleType':['A'],'passwordExpiryDays':30,'rutNumber':'12345678-k','userId':'jacksteve','lastModifiedPassDate':'10/10/2017' };
						var ctx = session.name('cache') || session.createContext('cache');
						ctx.setVar('token', token);
						// enviar salida en caso de ser necesario en este punto
                        session.output.write(salida);
  hm.response.set('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  hm.response.set('Access-Control-Allow-Headers', 'Content-Type, access-token');
 hm.response.set('Access-Control-Expose-Headers', 'access-token');
hm.response.set('access-token', token);

					}

				}

			);

		}

	}

);