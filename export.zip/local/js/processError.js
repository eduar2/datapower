//Import Required Packages

var JOSE=require('jose');
var JWT=require('jwt');
var hm = require('header-metadata');

//se lee input como JSON 
session.input.readAsBuffer(function(error, buffer) {
	if (error) {
		
		var ctx = session.name('cache') || session.createContext('cache');
		ctx.setVar('retorno', '1');
		ctx.setVar('error', '1');
		ctx.setVar('EstadoServicio', '100');
		ctx.setVar('EstadoServicioDesc', 'No es posible leer JSON:' + error);
		ctx.setVar('is_data', '1');
        session.reject('No es posible leer entrada: ' + error);

    } else {

			
		var ctx = session.name('cache') || session.createContext('cache');
		var codError = ctx.getVar('error');
		var messageError = ctx.getVar('messageError');
		var reason = ctx.getVar('reason');
		var salida;
		salida = { 'error': { 'code': codError, 'message': messageError, 'errors': [ { 'reason': reason, 'fieldList': [] }]}};
		session.output.write(salida);
                hm.response.set('Content-Type', 'application/json');
	        hm.current.set('Content-Type', 'application/json');	
	}
});